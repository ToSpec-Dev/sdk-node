# @tospec/redact

**A structured-first redaction engine for JSON and XML request/response bodies.**
Streaming path-trie redaction with deterministic HMAC tokenization, shape-preserving
masking, and a Luhn-validated PAN / PII detector layer. An embarrassingly small
dependency footprint — pure CPU plus two tiny runtime deps (`js-yaml`, `sax`).

[![License](https://img.shields.io/badge/license-Apache--2.0-blue.svg)](LICENSE)

This is the engine behind the [ToSpec](https://tospec.dev) certification platform,
ported to Node/TypeScript. It runs at two enforcement points from the **same compiled
ruleset**: the capture gateway (server side) and inside a provider's own process via the
ToSpec SDK (so sensitive values are redacted *before* they ever leave provider
infrastructure). It is a faithful port of the .NET engine
[`tospec/redact-dotnet`](https://github.com/tospec/redact-dotnet) and produces
**byte-identical output** over the shared
[`tospec/sdk-protocol`](https://github.com/tospec/sdk-protocol) fixtures — the two ports
are provably one engine.

## Why structured-first?

Request/response bodies are JSON or XML the overwhelming majority of the time. Treating
them as *structures* rather than strings means redaction is a single streaming rewrite
driven by a path-trie compiled from your rules — no DOM, no full-buffer regex scan on the
common path. Regex is the *fallback* layer for free-text fields, and even there PAN
candidates are Luhn-validated in code to kill false positives.

## Install

```sh
npm install @tospec/redact
```

## Quick start

Rules are authored in YAML and compiled once; the compiled ruleset is then applied to
each body.

```ts
import {
  compileRuleset,
  RedactionKeyring,
  JsonBodyRedactor,
  RedactionStatus,
} from "@tospec/redact";

// 1. Compile a ruleset (do this once, cache the result).
const compiled = compileRuleset(`
  body:
    - { path: "$.payment.cardNumber", action: hash }   # deterministic token
    - { path: "$.guest.email",        action: mask, keep: domain }
    - { path: "$..password",          action: drop }
  freetext:
    scan_unknown: true
    detectors: [pan_luhn, email]
  defaults:
    unknown_pii_policy: detect_and_hash
`);
if (!compiled.success) throw new Error(JSON.stringify(compiled.errors));

// 2. A per-tenant HMAC keyring drives deterministic tokenization.
const keys = new RedactionKeyring(myKeyBytes, 1);

// 3. Redact a body. The engine is stateless and thread-safe; reuse the singleton.
const result = JsonBodyRedactor.redact(Buffer.from(json, "utf8"), compiled.ruleset!, keys);
if (result.status === RedactionStatus.Rewritten) {
  const redacted = result.output!.toString("utf8");
  // "$.payment.cardNumber" is now "tsr_v1_<base32>", email masked, passwords dropped.
}
```

XML bodies use `XmlBodyRedactor` with the same ruleset and API;
`resolveBodyRedactor(contentFormat)` picks the right redactor by format.

## Actions

| Action           | Effect |
|------------------|--------|
| `drop`           | Remove the value entirely. |
| `mask`           | Shape-preserving mask (`j***@d***.com`, last-4). `keep: domain` / `keep: last4`. |
| `hash`           | Deterministic `HMAC-SHA-256` → `tsr_v{ver}_{base32}` token. Same input ⇒ same token, so equality assertions and cross-request joins survive redaction. |
| `tokenize_typed` | Hash plus a typed shadow value retained only in evaluator memory; never persisted. |

Paths use a JSONPath subset (child, recursive descent `..`, wildcard index `[*]`) chosen
to be compilable into the streaming trie. Free-text detectors: `pan_luhn`, `email`.

## The guarantee

Values fed to the engine **never survive into its output**. A Luhn-valid PAN, an email,
and auth-shaped secrets come out tokenized, masked, or dropped — the raw bytes are absent.
This is enforced structurally (see `test/redactionGuarantee.test.ts`) and holds even when
no path rule targets the value, via the free-text detector layer. A redactor never throws
on bad input: malformed bodies return `RedactionStatus.MalformedInput` and the caller owns
the drop-or-persist decision.

## Cross-language parity

`@tospec/redact` and [`redact-dotnet`](https://github.com/tospec/redact-dotnet) reproduce
the [`sdk-protocol`](https://github.com/tospec/sdk-protocol) golden fixtures **byte-for-byte** —
the token format (`tsr_v{ver}_{base32}`), the compiled-ruleset schema (v1), and every
`body_in → body_out` redaction vector. `test/fixtures.test.ts` loads those goldens
directly from the shared repo and asserts identical output. The redaction *output* is the
contract; both ports honor it exactly.

## Performance

Redaction is one streaming pass with no DOM. The throughput target for the SDK's captured
bodies (bounded to ≤ 64 KB) is **sub-few-milliseconds per body**; the harness below
measures the three canonical ruleset shapes across payload sizes.

```sh
npm run bench
```

`Node v22 · macOS · Apple silicon`. Throughput is `payloadBytes / mean`, single-threaded.
The harness also prints wall time, process CPU time, and CPU per MiB so speedups can be
checked against production host cost. Targeted path rules should stay near pure traversal
cost; `scan_unknown` is the higher-CPU safety net for values that cannot be addressed by
path.

| Ruleset   | Payload | Throughput | Wall/op | CPU/op | CPU/MiB |
|-----------|--------:|-----------:|--------:|-------:|--------:|
| NoMatch   |   1 KB  |  ~95 MiB/s |   11 us |  20 us | 18.93 ms |
| NoMatch   |   8 KB  | ~126 MiB/s |   62 us |  63 us |  8.03 ms |
| NoMatch   |  64 KB  | ~130 MiB/s |  483 us | 484 us |  7.74 ms |
| NoMatch   |   1 MB  | ~111 MiB/s | 8.98 ms | 9.86 ms |  9.86 ms |
| Typical   |   1 KB  |  ~34 MiB/s |   31 us |  39 us | 36.89 ms |
| Typical   |   8 KB  |  ~40 MiB/s |  198 us | 202 us | 25.72 ms |
| Typical   |  64 KB  |  ~40 MiB/s | 1.57 ms | 1.60 ms | 25.58 ms |
| Typical   |   1 MB  |  ~37 MiB/s | 27.34 ms | 28.81 ms | 28.81 ms |
| ScanHeavy |   1 KB  |  ~18 MiB/s |   58 us |  65 us | 60.72 ms |
| ScanHeavy |   8 KB  |  ~18 MiB/s |  428 us | 435 us | 55.21 ms |
| ScanHeavy |  64 KB  |  ~18 MiB/s | 3.47 ms | 3.53 ms | 56.52 ms |
| ScanHeavy |   1 MB  |  ~18 MiB/s | 56.98 ms | 59.75 ms | 59.75 ms |

**Benchmark parity note.** These are the Node twin of the
[`redact-dotnet`](https://github.com/tospec/redact-dotnet#performance) BenchmarkDotNet
numbers. The .NET engine is several times faster in raw throughput (~150–550 MB/s) because
it writes into pooled UTF-8 spans (`Utf8JsonReader`/`Utf8JsonWriter`), whereas this port
builds JavaScript strings. That gap is a *throughput* difference only — the **redaction
output is byte-identical** (proven by the shared fixtures). For the ToSpec SDK's use case —
bodies bounded to ≤ 64 KB, redacted on the forwarding path — the worst measured JSON shape
(ScanHeavy at 64 KB) is ~3.5 ms CPU/op, NoMatch is under 0.5 ms, and the deliberately
hash-heavy Typical shape is ~1.6 ms. The redactor does not start worker threads or shift
work to background CPU; callers should size the forwarding path from the CPU/op and
CPU/MiB columns. Treat these
as a dev-laptop floor, not a tuned measurement.

## Building from source

```sh
npm install
npm run build
npm test
```

Requires Node ≥ 20.

## License

[Apache-2.0](LICENSE).
